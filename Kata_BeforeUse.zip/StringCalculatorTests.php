<?php
class StringCalculatorTests extends EnhanceTestFixture
{
        private $target;

        public function setUp()
        {
                $this->target = Enhance::getCodeCoverageWrapper('StringCalculator');
        }

        public function startWritingTests()
        {

        }
}
?>