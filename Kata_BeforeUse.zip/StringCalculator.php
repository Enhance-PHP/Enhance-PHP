<?php
class StringCalculator
{
    public function add($numbers)
    {

    }
}
?>